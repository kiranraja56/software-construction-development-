/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package common;

import java.awt.Desktop;
import java.io.File;
import javax.swing.JOptionPane;

/**
 *
 * @author Itcomplex
 */
public class openpdf {
    public static void openbyid(String id) {
        try {
            // Use System.getProperty to get the correct desktop path
            String desktopPath = System.getProperty("user.home") + File.separator + "Desktop" + File.separator;
            File pdfFile = new File(desktopPath + id + ".pdf");
            
            if (pdfFile.exists()) {
                // Use Desktop class for cross-platform PDF opening
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    // Fallback to runtime exec if Desktop is not supported
                    Process p = Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + pdfFile.getAbsolutePath());
                }
            } else {
                JOptionPane.showMessageDialog(null, "File does not exist: " + pdfFile.getAbsolutePath());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error opening PDF: " + e.getMessage());
        }
    }
}
