/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.User;

public class userdao {

    public static void save(User user) {
        String query = "INSERT INTO user (name, email, phoneno, password,role) VALUES (?, ?, ?, ?,?)";

        try {
            Connection con = sqlconnection.getCon();
            if (con == null) {
                System.out.println("Database connection failed!");
                return;
            }

            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, user.getName());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getPhoneno());
            pstmt.setString(4, user.getPassword());
            pstmt.setString(5, user.getRole());

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("User registered successfully in MySQL!");
            } else {
                System.out.println("Failed to register user.");
            }

            pstmt.close();
            con.close();
        } catch (SQLException e) {
            System.out.println("SQL error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static User login(String email, String password, String role) {
        User user = null;
        try {
            ResultSet rs = dboperation.getData("SELECT * FROM user WHERE email='" + email + "' AND password ='" + password + "' AND role ='" + role + "'");
            if (rs.next()) { // Check if a matching user is found
                        user = new User();
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e, "Message", JOptionPane.ERROR_MESSAGE);
        }
        return user;
    }
}
