/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Bill;

/**
 *
 * @author Itcomplex
 */
public class billdao {

    public static String getid() {
        int id = 1;
        try {
            ResultSet rs = dboperation.getData("SELECT MAX(b_id) FROM bill");
            if (rs.next()) {
                id = rs.getInt(1);
                id = id + 1;

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return String.valueOf(id);
    }

    public static int save(Bill bill) {
        int generatedId = -1;
        try {
            String query = "INSERT INTO bill (t_id, name, mobileno, email, date, total) VALUES (?, ?, ?, ?, ?, ?)";
            java.sql.Connection con = sqlconnection.getCon();
            java.sql.PreparedStatement pst = con.prepareStatement(query, java.sql.Statement.RETURN_GENERATED_KEYS);

            pst.setString(1, bill.getTid());
            pst.setString(2, bill.getName());
            pst.setString(3, bill.getMobileno());
            pst.setString(4, bill.getEmail());
            pst.setString(5, bill.getDate());
            pst.setString(6, bill.getTotal());
            pst.executeUpdate();

            // Retrieve the generated bill ID
            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) {
                generatedId = rs.getInt(1);
                bill.setId(generatedId);  // ✅ Correctly setting the ID here
            }

            pst.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error saving bill: " + e.getMessage());
        }
        return generatedId;
    }

    public static ArrayList<Bill> getallrecordsbydate(String date) {
        ArrayList<Bill> arraylist = new ArrayList();
        try {
            ResultSet rs = dboperation.getData("SELECT * FROM bill WHERE date='" + date + "'");
            while (rs.next()) {
                Bill bill = new Bill();
                bill.setId(rs.getInt("b_id"));
                bill.setTid(rs.getString("t_id"));
                bill.setName(rs.getString("name"));
                bill.setEmail(rs.getString("email"));
                bill.setMobileno(rs.getString("mobileno"));
                bill.setDate(rs.getString("date"));
                bill.setTotal(rs.getString("total"));
                arraylist.add(bill);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arraylist;
    }

}
