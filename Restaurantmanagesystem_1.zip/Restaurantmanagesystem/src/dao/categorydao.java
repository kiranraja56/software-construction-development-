/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Category;

/**
 *
 * @author Itcomplex
 */
public class categorydao {

    public static void save(Category category) {
        String query = "INSERT INTO category (categoryname) VALUES ('" + category.getCategoryname() + "')";
        dboperation.setordeletedata(query, "Category Added Successfully");
    }

    public static ArrayList<Category> getallrecords() {
        ArrayList<Category> arraylist = new ArrayList<>();
        try {
            ResultSet rs = dboperation.getData("SELECT * FROM category");
            while (rs.next()) {
                Category category = new Category();
                category.setId(rs.getInt("id"));
                category.setCategoryname(rs.getString("categoryname"));
                arraylist.add(category);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arraylist;
    }

    public static void delete(String id) {
        String Query = "DELETE FROM category WHERE id='" + id + "'";
        dboperation.setordeletedata(Query, "Category Deleted Successfully");
    }
}
