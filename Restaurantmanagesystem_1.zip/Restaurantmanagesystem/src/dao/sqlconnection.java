package dao;

import java.sql.*;

public class sqlconnection {

    public static Connection getCon() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Database URL, username, and password
            String DB_URL = "jdbc:mysql://localhost:3306/restaurantmanagesystem";
            String USER = "root";
            String PASSWORD = "";

            // Establish connection
            Connection con = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            System.out.println("Database connection established successfully.");
            return con; // Return the connection object after successful connection
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Error: Unable to load driver class!");
            ex.printStackTrace();
        } catch (SQLException ex) {
            System.out.println("Error: Unable to connect to the database!");
            ex.printStackTrace();
        }
        return null; // Return null if there is an error
      
    }
    
  
}
