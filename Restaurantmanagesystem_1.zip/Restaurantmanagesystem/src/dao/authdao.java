/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Fooditems;
import model.User;

/**
 *
 * @author Itcomplex
 */
public class authdao {

    public static void save(User user) {
        String query;
        if (user.getRole().equalsIgnoreCase("Admin")) {
            query = "INSERT INTO user (name, email, phoneno, password, role) VALUES (?, ?, ?, ?, ?)";
        } else {
            query = "INSERT INTO authentication (name, email, phoneno, password, role) VALUES (?, ?, ?, ?, ?)";
        }

        try {
            Connection con = sqlconnection.getCon();
            if (con == null) {
                System.out.println("Database connection failed!");
                return;
            }

            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, user.getName());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getPhoneno());
            pstmt.setString(4, user.getPassword());
            pstmt.setString(5, user.getRole());

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println(user.getRole() + " registered successfully!");
            } else {
                System.out.println("Failed to register user.");
            }

            pstmt.close();
            con.close();
        } catch (SQLException e) {
            System.out.println("SQL error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static User login(String email, String password, String role) {
        User user = null;
        String query;

        // Debug prints to check login values
        System.out.println("Attempting login...");
        System.out.println("Email: " + email);
        System.out.println("Password: " + password);
        System.out.println("Role: " + role);

        if (role.equalsIgnoreCase("Admin")) {
            query = "SELECT * FROM user WHERE email=? AND password=? AND role=?";
        } else {
            query = "SELECT * FROM authentication WHERE email=? AND password=? AND role=?";
        }

        try {
            Connection con = sqlconnection.getCon();
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, email);
            pstmt.setString(2, password);
            pstmt.setString(3, role);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                user = new User();
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                System.out.println("Login successful for " + email); // Debug print for success
            } else {
                System.out.println("Login failed for " + email); // Debug print for failure
            }

            rs.close();
            pstmt.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e, "Message", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return user;
    }

    public static void update(User user) {
        String query = "UPDATE authentication SET name='" + user.getName() + "', email='" + user.getEmail() + "', phoneno='" + user.getPhoneno() + "',password='" + user.getPassword() + "',role='" + user.getRole() + "', WHERE id=" + user.getId();
        dboperation.setordeletedata(query, "Product Updated Successfully");
    }
    

    public static ArrayList<User> getAllUsers() {
        ArrayList<User> users = new ArrayList<>();
        String query = "SELECT * FROM authentication ";  // Query to fetch all users
        try {
Connection con = sqlconnection.getCon();
PreparedStatement pst = con.prepareStatement(query); 
ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPhoneno(rs.getString("phoneno"));
                user.setPassword(rs.getString("password"));
                user.setRole(rs.getString("role"));
                users.add(user);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();  // Handle exception properly
        }
        return users;
    }

    public static void delete(String id) {
        String Query = "DELETE FROM authentication WHERE id='" + id + "'";
        dboperation.setordeletedata(Query, "User removed Successfully");
    }
}
