/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Fooditems;

/**
 *
 * @author Itcomplex
 */
public class fooditemsdao {

    public static void save(Fooditems fooditem) {
        String query = "INSERT INTO food_items(f_name,category,price) VALUES('" + fooditem.getName() + "','" + fooditem.getCategory() + "','" + fooditem.getPrice() + "')";
        dboperation.setordeletedata(query, "Item Added Successfully");
    }

    public static ArrayList<Fooditems> getallrecord() {
        ArrayList<Fooditems> list = new ArrayList();
        try {
            ResultSet rs = dboperation.getData("SELECT * FROM food_items");
            while (rs.next()) {
                Fooditems fooditem = new Fooditems();
                fooditem.setId(rs.getInt("f_id"));
                fooditem.setName(rs.getString("f_name"));
                fooditem.setCategory(rs.getString("category"));
                fooditem.setPrice(rs.getString("price"));
                list.add(fooditem);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return list;
    }

    public static void update(Fooditems fooditem) {
        String query = "UPDATE food_items SET f_name='" + fooditem.getName() + "', category='" + fooditem.getCategory() + "', price='" + fooditem.getPrice() + "' WHERE f_id=" + fooditem.getId();
        dboperation.setordeletedata(query, "Product Updated Successfully");
    }

    public static void delete(String id) {
        String query = "DELETE FROM food_items WHERE f_id='" + id + "'";
        dboperation.setordeletedata(query, "Deleted Successfully");
    }

    public static ArrayList<Fooditems> getallrecordsbycategory(String category) {
        ArrayList<Fooditems> arraylist = new ArrayList();
        try {
            ResultSet rs = dboperation.getData("SELECT * FROM food_items WHERE category='" + category + "'");

            while (rs.next()) {
                Fooditems fooditem = new Fooditems();
                fooditem.setName(rs.getString("f_name"));
                arraylist.add(fooditem);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arraylist;
    }

    public static ArrayList<Fooditems> filterproductbyname(String name, String category) {
        ArrayList<Fooditems> arraylist = new ArrayList();
        try {
            ResultSet rs = dboperation.getData("SELECT * FROM food_items WHERE f_name ='" + name + "' AND category='" + category + "'");
            while (rs.next()) {
                Fooditems fooditem = new Fooditems();
                fooditem.setName(rs.getString("f_name"));
                arraylist.add(fooditem);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arraylist;
    }

    public static Fooditems getfooditemsbyname(String name) {
        Fooditems fooditem = new Fooditems();
        try {
            ResultSet rs = dboperation.getData("SELECT * FROM food_items WHERE f_name='" + name + "'");

            while (rs.next()) {
                fooditem.setName(rs.getString(2));
                fooditem.setCategory(rs.getString(3));
                fooditem.setPrice(rs.getString(4));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return fooditem;
    }
}
