/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.payment;

/**
 *
 * @author Itcomplex
 */
public class paymentdao {

    // Database connection
    private Connection conn;

    public paymentdao(Connection conn) {
        this.conn = conn;
    }

    // Method to add payment record
    public boolean addPayment(payment pay) {
        String query = "INSERT INTO payments (bill_id, payment_method, amount, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setInt(1, pay.getBill_id());
            pst.setString(2, pay.getPayment_method());
            pst.setString(3, pay.getAmount());
            pst.setString(4, pay.getStatus());
            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to update payment status (if required)
    public boolean updatePaymentStatus(int paymentId, String status) {
        String query = "UPDATE payments SET status = ? WHERE id = ?";
        try (PreparedStatement pst = conn.prepareStatement(query)) {
            pst.setString(1, status);
            pst.setInt(2, paymentId);
            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
